package techyield;
/**
 * @author Satyanarayana Gokavarapu
 *
 */
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(OrderStatus.NewOrder);
		System.out.println(OrderStatus.OnHold);
	}

}
