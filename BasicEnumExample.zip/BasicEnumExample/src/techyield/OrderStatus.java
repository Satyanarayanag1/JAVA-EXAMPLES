/**
 * 
 */
package techyield;

/**
 * @author Satyanarayana Gokavarapu
 *
 */
public enum OrderStatus {
	NewOrder,
	OrderPicked,
	OrderPending,
	PaymentReceived, 
	ShipmentInProgress,
	OrderShipped,
	Delivered, 
	Canceled, 
	OnHold;
}
